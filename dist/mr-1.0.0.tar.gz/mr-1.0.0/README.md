# amyTools

#### 介绍
分支轻量工具

#### 安装教程

1.  安装最新的python环境
2.  pip3 install mr

#### 使用说明

####命令
mr
基于当前分支创建远程分支并发起merge request，目标分支为当前分支